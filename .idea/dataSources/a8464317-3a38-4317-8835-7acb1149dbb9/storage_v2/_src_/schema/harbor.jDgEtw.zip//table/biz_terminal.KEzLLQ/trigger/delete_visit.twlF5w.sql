CREATE TRIGGER delete_visit
  BEFORE UPDATE
  ON biz_terminal
  FOR EACH ROW
  BEGIN

DELETE FROM harbor.biz_terminal_visit WHERE new.terminal_number is null and harbor.biz_terminal_visit.terminal_number=old.terminal_number;

END;

