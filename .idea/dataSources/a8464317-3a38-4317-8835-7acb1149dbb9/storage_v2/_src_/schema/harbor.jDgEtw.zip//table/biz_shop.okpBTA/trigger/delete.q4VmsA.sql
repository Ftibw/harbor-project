CREATE TRIGGER `delete`
  BEFORE DELETE
  ON biz_shop
  FOR EACH ROW
  BEGIN

DELETE FROM harbor.biz_shop_visit WHERE harbor.biz_shop_visit.shop_number=old.shop_number;

END;

