CREATE TRIGGER insert_visit
  AFTER INSERT
  ON biz_terminal
  FOR EACH ROW
  begin

INSERT INTO biz_terminal_visit(terminal_number,terminal_visit_amount,terminal_visit_time) VALUES(new.terminal_number,0,CURRENT_TIMESTAMP);

END;

