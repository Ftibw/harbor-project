CREATE TRIGGER `insert`
  AFTER INSERT
  ON biz_shop
  FOR EACH ROW
  BEGIN

INSERT INTO biz_shop_visit(shop_number,shop_visit_amount,shop_visit_time) VALUES(new.shop_number,0,CURRENT_TIMESTAMP);

END;

