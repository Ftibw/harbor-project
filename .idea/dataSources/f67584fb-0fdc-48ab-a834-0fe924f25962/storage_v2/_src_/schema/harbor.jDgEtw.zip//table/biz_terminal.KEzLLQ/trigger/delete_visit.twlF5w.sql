CREATE TRIGGER delete_visit
  BEFORE DELETE
  ON biz_terminal
  FOR EACH ROW
  BEGIN

DELETE FROM harbor.biz_terminal_visit WHERE harbor.biz_terminal_visit.terminal_number=old.terminal_number;
END;

